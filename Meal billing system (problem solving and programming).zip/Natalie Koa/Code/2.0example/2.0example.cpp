#include <iostream>
#include <iomanip>
#include <vector>
#include <string>

// define meal price 
#define price_a 9.00 // nasi lemak
#define price_b 6.00 //masala dosa
#define price_c 5.00 // hamburger n fries
#define price_d 12.00 // fish n chips 
#define price_e 8.50 //  mee goreng ayam 

// drinks price 
#define price_f 0.50 // chinese teh, water.
#define price_g 3.50 // milo & kopi o. 
#define price_h 9.90 // avocado smoothie with chocolate syrup vanilla smoothie 

//sales and service tax
#define sst 0.10 

using namespace std;

struct Feedback {
	string name;
	string email;
	string comments;
};


vector<Feedback> feedbackList;

char mealtype;
int quantity;
int totalcustomers = 0;
double totalsales = 0.0;
double totalsstcollected = 0.0;

// function to display logo
void displayLogo() {
	cout << "-------------------------------------------------------------------------" << endl;
	cout << "-------------------------------------------------------------------------" << endl;
	cout << endl;
	cout << "                        Welcome to H&S Restaurant                        " << endl << endl;
	cout << "-------------------------------------------------------------------------" << endl;
	cout << "-------------------------------------------------------------------------" << endl;
	cout << "-------------------------------------------------------------------------" << endl;
	cout << "-------------------------------------------------------------------------" << endl;
	cout << "----                                                                 ----" << endl;
	cout << "----                                                                 ----" << endl;
	cout << "----       HHHH     HHHH                          SSSSSSSSSS         ----    " << endl;
	cout << "----       HHHH     HHHH                         SSSSSSSSSSS         ----    " << endl;
	cout << "----       HHHH     HHHH                       SS                    ----    " << endl;
	cout << "----       HHHH     HHHH                       SS                    ----    " << endl;
	cout << "----       HHHHHHHHHHHHH          &&&           SSSSSSSSSSSS         ----    " << endl;
	cout << "----       HHHHHHHHHHHHH          &&&            SSSSSSSSSSSS        ----    " << endl;
	cout << "----       HHHH     HHHH                                    SS       ----    " << endl;
	cout << "----       HHHH     HHHH                                    SS       ----    " << endl;
	cout << "----       HHHH     HHHH                          SSSSSSSSSSS        ----    " << endl;
	cout << "----       HHHH     HHHH                         SSSSSSSSSSSS        ----    " << endl;
	cout << "----                                                                 ----" << endl;
	cout << "----                                                                 ----" << endl;
	cout << "-------------------------------------------------------------------------" << endl;
	cout << "_________________________________________________________________________" << endl;
	cout << endl << endl << endl << endl;
}

// function to display menu
void menu()
{
	cout << "----------------------------------------" << endl;
	cout << "Menu:\n";
	cout << "----------------------------------------" << endl;
	cout << "^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^" << endl;
	cout << "^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^" << endl;
	cout << "------------------FOOD------------------" << endl;
	cout << "a - Nasi Lemak		          RM" << price_a << endl;
	cout << "b - Maala Dosa		          RM" << price_b << endl;
	cout << "c - Hamburger		          RM" << price_c << endl;
	cout << "d - Fish N Chips                  RM" << price_d << endl;
	cout << "e - Mee Goreng Ayam               RM" << price_e << endl;
	cout << "----------------------------------------" << endl;
	cout << "^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^" << endl;
	cout << "^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^" << endl;
	cout << "-----------------DRINKS-----------------" << endl;
	cout << "f - Chinese Teh Ping		  RM" << price_f << endl;
	cout << "g - Water			  RM" << price_f << endl;
	cout << "h - Milo			  RM" << price_g << endl;
	cout << "i - Kopi O			  RM" << price_g << endl;
	cout << "j - Avocado Chocolate Smoothie    RM" << price_h << endl;
	cout << "k - Vanilla Smoothie		  RM" << price_h << endl;
	cout << "----------------------------------------" << endl;
}

void leaveFeedback()
{
	Feedback feedback;

	cout << "Leave Feedback\n";
	cout << "Name: ";
	cin.ignore(); // Clear the newline character left in the input buffer
	getline(cin, feedback.name);

	cout << "Email: ";
	cin >> feedback.email;

	cout << "Comments: ";
	cin.ignore(); // Clear any newline character left in the input buffer
	getline(cin, feedback.comments);

	// Flush the output buffer and clear the input buffer
	cout << "Thank you for leaving feedback!" << endl << std::flush;
	cin.clear();
	cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

	feedbackList.push_back(feedback); // Add feedback to the vector
}



void customerOrder() {
	cout << endl;
	double subtotal;
	double sstamount;
	double totalamount;
	double amountpaid;

	while (true) { // promt the user ti enter their order (MEALTYPE)
		cout << "----------------------------------------" << endl;
		cout << "What Would You Like To Order?" << endl;
		cout << "Enter your order (Enter x to exit): ";

		cin >> mealtype;
		double totalcharge = 0.0;
		// handle different meal options 
		switch (tolower(mealtype))
		{
		case 'a':
			cout << "Quantity: ";
			cin >> quantity;
			subtotal = price_a * quantity;
			sstamount = subtotal * sst;
			totalamount = subtotal + sstamount;
			cout << endl << endl;
			cout << "Order Details: " << endl;
			cout << "Order: " << mealtype << endl;
			cout << "Quantity: " << quantity << endl;
			cout << "Subtotal:RM  " << fixed << setprecision(2) << subtotal << endl;
			cout << "SST (" << (sst * 100) << "%):RM  " << sstamount << endl;
			cout << "Total Amount:RM  " << totalamount << endl;
			cout << "Enter Amount Paid: RM  ";
			cin >> amountpaid;

			//calculate change 
			do {
				if (amountpaid >= totalamount) {
					double change = amountpaid - totalamount;
					cout << "Change: RM" << fixed << setprecision(2) << change << endl;
				}
				else {
					cout << "Insufficient Payment. Please Pay The Correct Amount" << endl;
					cout << "Total Amount: RM" << fixed << setprecision(2) << totalamount << endl; // Display the correct total amount
					cout << "Enter Amount Paid: RM  ";
					cin >> amountpaid;
				}
			} while (totalamount > amountpaid);
			totalsales += subtotal;
			totalsstcollected += sstamount;
			totalcustomers++;
			totalcharge = price_a * quantity;

			break;
		case 'b':
			cout << "Quantity: ";
			cin >> quantity;
			subtotal = price_b * quantity;
			sstamount = subtotal * sst;
			totalamount = subtotal + sstamount;
			cout << endl << endl;
			cout << "Order Details: " << endl;
			cout << "Order: " << mealtype << endl;
			cout << "Quantity: " << quantity << endl;
			cout << "Subtotal:RM  " << fixed << setprecision(2) << subtotal << endl;
			cout << "SST (" << (sst * 100) << "%):RM  " << sstamount << endl;
			cout << "Total Amount:RM  " << totalamount << endl;
			cout << "Enter Amount Paid: RM  ";
			cin >> amountpaid;

			//calculate change 
			do {
				if (amountpaid >= totalamount) {
					double change = amountpaid - totalamount;
					cout << "Change: RM" << fixed << setprecision(2) << change << endl;
				}
				else {
					cout << "Insufficient Payment. Please Pay The Correct Amount" << endl;
					cout << "Total Amount: RM" << fixed << setprecision(2) << totalamount << endl; // Display the correct total amount
					cout << "Enter Amount Paid: RM  ";
					cin >> amountpaid;
				}
			} while (totalamount > amountpaid);
			totalsales += subtotal;
			totalsstcollected += sstamount;
			totalcustomers++;

			totalcharge = price_b * quantity;
			break;

		case 'c':
			cout << "Quantity: ";
			cin >> quantity;
			subtotal = price_c * quantity;
			sstamount = subtotal * sst;
			totalamount = subtotal + sstamount;
			cout << endl << endl;
			cout << "Order Details: " << endl;
			cout << "Order: " << mealtype << endl;
			cout << "Quantity: " << quantity << endl;
			cout << "Subtotal:RM  " << fixed << setprecision(2) << subtotal << endl;
			cout << "SST (" << (sst * 100) << "%):RM  " << sstamount << endl;
			cout << "Total Amount:RM  " << totalamount << endl;
			cout << "Enter Amount Paid: RM  ";
			cin >> amountpaid;

			//calculate change 
			do {
				if (amountpaid >= totalamount) {
					double change = amountpaid - totalamount;
					cout << "Change: RM" << fixed << setprecision(2) << change << endl;
				}
				else {
					cout << "Insufficient Payment. Please Pay The Correct Amount" << endl;
					cout << "Total Amount: RM" << fixed << setprecision(2) << totalamount << endl; // Display the correct total amount
					cout << "Enter Amount Paid: RM  ";
					cin >> amountpaid;
				}
			} while (totalamount > amountpaid);
			totalsales += subtotal;
			totalsstcollected += sstamount;
			totalcustomers++;
			totalcharge = price_c * quantity;
			break;
		case 'd':
			cout << "Quantity: ";
			cin >> quantity;
			subtotal = price_d * quantity;
			sstamount = subtotal * sst;
			totalamount = subtotal + sstamount;
			cout << endl << endl;
			cout << "Order Details: " << endl;
			cout << "Order: " << mealtype << endl;
			cout << "Quantity: " << quantity << endl;
			cout << "Subtotal:RM  " << fixed << setprecision(2) << subtotal << endl;
			cout << "SST (" << (sst * 100) << "%):RM  " << sstamount << endl;
			cout << "Total Amount:RM  " << totalamount << endl;
			cout << "Enter Amount Paid: RM  ";
			cin >> amountpaid;

			//calculate change 
			do {
				if (amountpaid >= totalamount) {
					double change = amountpaid - totalamount;
					cout << "Change: RM" << fixed << setprecision(2) << change << endl;
				}
				else {
					cout << "Insufficient Payment. Please Pay The Correct Amount" << endl;
					cout << "Total Amount: RM" << fixed << setprecision(2) << totalamount << endl; // Display the correct total amount
					cout << "Enter Amount Paid: RM  ";
					cin >> amountpaid;
				}
			} while (totalamount > amountpaid);
			totalsales += subtotal;
			totalsstcollected += sstamount;
			totalcustomers++;
			totalcharge = price_d * quantity;
			break;
		case 'e':
			cout << "Quantity: ";
			cin >> quantity;
			subtotal = price_e * quantity;
			sstamount = subtotal * sst;
			totalamount = subtotal + sstamount;
			cout << endl << endl;
			cout << "Order Details: " << endl;
			cout << "Order: " << mealtype << endl;
			cout << "Quantity: " << quantity << endl;
			cout << "Subtotal:RM  " << fixed << setprecision(2) << subtotal << endl;
			cout << "SST (" << (sst * 100) << "%):RM  " << sstamount << endl;
			cout << "Total Amount:RM  " << totalamount << endl;
			cout << "Enter Amount Paid: RM  ";
			cin >> amountpaid;

			//calculate change 
			do {
				if (amountpaid >= totalamount) {
					double change = amountpaid - totalamount;
					cout << "Change: RM" << fixed << setprecision(2) << change << endl;
				}
				else {
					cout << "Insufficient Payment. Please Pay The Correct Amount" << endl;
					cout << "Total Amount: RM" << fixed << setprecision(2) << totalamount << endl; // Display the correct total amount
					cout << "Enter Amount Paid: RM  ";
					cin >> amountpaid;
				}
			} while (totalamount > amountpaid);
			totalsales += subtotal;
			totalsstcollected += sstamount;
			totalcustomers++;
			totalcharge = price_e * quantity;
			break;
		case 'f':
			cout << "Quantity: ";
			cin >> quantity;
			subtotal = price_f * quantity;
			sstamount = subtotal * sst;
			totalamount = subtotal + sstamount;
			cout << endl << endl;
			cout << "Order Details: " << endl;
			cout << "Order: " << mealtype << endl;
			cout << "Quantity: " << quantity << endl;
			cout << "Subtotal:RM  " << fixed << setprecision(2) << subtotal << endl;
			cout << "SST (" << (sst * 100) << "%):RM  " << sstamount << endl;
			cout << "Total Amount:RM  " << totalamount << endl;
			cout << "Enter Amount Paid: RM  ";
			cin >> amountpaid;

			//calculate change 
			do {
				if (amountpaid >= totalamount) {
					double change = amountpaid - totalamount;
					cout << "Change: RM" << fixed << setprecision(2) << change << endl;
				}
				else {
					cout << "Insufficient Payment. Please Pay The Correct Amount" << endl;
					cout << "Total Amount: RM" << fixed << setprecision(2) << totalamount << endl; // Display the correct total amount
					cout << "Enter Amount Paid: RM  ";
					cin >> amountpaid;
				}
			} while (totalamount > amountpaid);
			totalsales += subtotal;
			totalsstcollected += sstamount;
			totalcustomers++;
			totalcharge = price_f * quantity;
			break;
		case 'g':
			cout << "Quantity: ";
			cin >> quantity;
			subtotal = price_f * quantity;
			sstamount = subtotal * sst;
			totalamount = subtotal + sstamount;
			cout << endl << endl;
			cout << "Order Details: " << endl;
			cout << "Order: " << mealtype << endl;
			cout << "Quantity: " << quantity << endl;
			cout << "Subtotal:RM  " << fixed << setprecision(2) << subtotal << endl;
			cout << "SST (" << (sst * 100) << "%):RM  " << sstamount << endl;
			cout << "Total Amount:RM  " << totalamount << endl;
			cout << "Enter Amount Paid: RM  ";
			cin >> amountpaid;

			//calculate change 
			do {
				if (amountpaid >= totalamount) {
					double change = amountpaid - totalamount;
					cout << "Change: RM" << fixed << setprecision(2) << change << endl;
				}
				else {
					cout << "Insufficient Payment. Please Pay The Correct Amount" << endl;
					cout << "Total Amount: RM" << fixed << setprecision(2) << totalamount << endl; // Display the correct total amount
					cout << "Enter Amount Paid: RM  ";
					cin >> amountpaid;
				}
			} while (totalamount > amountpaid);
			totalsales += subtotal;
			totalsstcollected += sstamount;
			totalcustomers++;
			totalcharge = price_f * quantity;
			break;
		case 'h':
			cout << "Quantity: ";
			cin >> quantity;
			subtotal = price_g * quantity;
			sstamount = subtotal * sst;
			totalamount = subtotal + sstamount;
			cout << endl << endl;
			cout << "Order Details: " << endl;
			cout << "Order: " << mealtype << endl;
			cout << "Quantity: " << quantity << endl;
			cout << "Subtotal:RM  " << fixed << setprecision(2) << subtotal << endl;
			cout << "SST (" << (sst * 100) << "%):RM  " << sstamount << endl;
			cout << "Total Amount:RM  " << totalamount << endl;
			cout << "Enter Amount Paid: RM  ";
			cin >> amountpaid;

			//calculate change 
			do {
				if (amountpaid >= totalamount) {
					double change = amountpaid - totalamount;
					cout << "Change: RM" << fixed << setprecision(2) << change << endl;
				}
				else {
					cout << "Insufficient Payment. Please Pay The Correct Amount" << endl;
					cout << "Total Amount: RM" << fixed << setprecision(2) << totalamount << endl; // Display the correct total amount
					cout << "Enter Amount Paid: RM  ";
					cin >> amountpaid;
				}
			} while (totalamount > amountpaid);
			totalsales += subtotal;
			totalsstcollected += sstamount;
			totalcustomers++;
			totalcharge = price_g * quantity;
			break;
		case 'i':
			cout << "Quantity: ";
			cin >> quantity;
			subtotal = price_g * quantity;
			sstamount = subtotal * sst;
			totalamount = subtotal + sstamount;
			cout << endl << endl;
			cout << "Order Details: " << endl;
			cout << "Order: " << mealtype << endl;
			cout << "Quantity: " << quantity << endl;
			cout << "Subtotal:RM  " << fixed << setprecision(2) << subtotal << endl;
			cout << "SST (" << (sst * 100) << "%):RM  " << sstamount << endl;
			cout << "Total Amount:RM  " << totalamount << endl;
			cout << "Enter Amount Paid: RM  ";
			cin >> amountpaid;

			//calculate change 
			do {
				if (amountpaid >= totalamount) {
					double change = amountpaid - totalamount;
					cout << "Change: RM" << fixed << setprecision(2) << change << endl;
				}
				else {
					cout << "Insufficient Payment. Please Pay The Correct Amount" << endl;
					cout << "Total Amount: RM" << fixed << setprecision(2) << totalamount << endl; // Display the correct total amount
					cout << "Enter Amount Paid: RM  ";
					cin >> amountpaid;
				}
			} while (totalamount > amountpaid);
			totalsales += subtotal;
			totalsstcollected += sstamount;
			totalcustomers++;
			totalcharge = price_g * quantity;
			break;
		case 'j':
			cout << "Quantity: ";
			cin >> quantity;
			subtotal = price_h * quantity;
			sstamount = subtotal * sst;
			totalamount = subtotal + sstamount;
			cout << endl << endl;
			cout << "Order Details: " << endl;
			cout << "Order: " << mealtype << endl;
			cout << "Quantity: " << quantity << endl;
			cout << "Subtotal:RM  " << fixed << setprecision(2) << subtotal << endl;
			cout << "SST (" << (sst * 100) << "%):RM  " << sstamount << endl;
			cout << "Total Amount:RM  " << totalamount << endl;
			cout << "Enter Amount Paid: RM  ";
			cin >> amountpaid;

			//calculate change 
			do {
				if (amountpaid >= totalamount) {
					double change = amountpaid - totalamount;
					cout << "Change: RM" << fixed << setprecision(2) << change << endl;
				}
				else {
					cout << "Insufficient Payment. Please Pay The Correct Amount" << endl;
					cout << "Total Amount: RM" << fixed << setprecision(2) << totalamount << endl; // Display the correct total amount
					cout << "Enter Amount Paid: RM  ";
					cin >> amountpaid;
				}
			} while (totalamount > amountpaid);
			totalsales += subtotal;
			totalsstcollected += sstamount;
			totalcustomers++;
			totalcharge = price_h * quantity;
			break;
		case 'k':
			cout << "Quantity: ";
			cin >> quantity;
			subtotal = price_h * quantity;
			sstamount = subtotal * sst;
			totalamount = subtotal + sstamount;
			cout << endl << endl;
			cout << "Order Details: " << endl;
			cout << "Order: " << mealtype << endl;
			cout << "Quantity: " << quantity << endl;
			cout << "Subtotal:RM  " << fixed << setprecision(2) << subtotal << endl;
			cout << "SST (" << (sst * 100) << "%):RM  " << sstamount << endl;
			cout << "Total Amount:RM  " << totalamount << endl;
			cout << "Enter Amount Paid: RM  ";
			cin >> amountpaid;

			//calculate change 
			do {
				if (amountpaid >= totalamount) {
					double change = amountpaid - totalamount;
					cout << "Change: RM" << fixed << setprecision(2) << change << endl;
				}
				else {
					cout << "Insufficient Payment. Please Pay The Correct Amount" << endl;
					cout << "Total Amount: RM" << fixed << setprecision(2) << totalamount << endl; // Display the correct total amount
					cout << "Enter Amount Paid: RM  ";
					cin >> amountpaid;
				}
			} while (totalamount > amountpaid);
			totalsales += subtotal;
			totalsstcollected += sstamount;
			totalcustomers++;
			totalcharge = price_h * quantity;
			break;
		case 'x': // exit order loop
			cout << endl;
			cout << "Exiting" << endl;
			cout << "Thank You For Your Service!" << endl;
			break;
		default:
			cout << "Invalid Order Selected" << endl; // handle invalid orders 
			break;
		}
		if (mealtype == 'x' || mealtype == 'X') {
			break;
		}
	}


}
// function to display daily sales report 
// calculates and display daily statistics 
void dailyReport() {
	cout << endl;
	cout << endl;
	cout << "-----------------------" << endl;
	cout << "Daily Meal Sales Report" << endl;
	cout << "-----------------------" << endl;
	cout << endl;
	cout << endl;

	cout << "Number Of Customers : " << totalcustomers << endl;
	cout << "Total Sales:RM  " << fixed << setprecision(2) << totalsales << endl;
	cout << "total SST Collected:RM  " << totalsstcollected << endl;
	cout << "Total Amount Collected:RM  " << (totalsales + totalsstcollected) << endl;

	// display final ending msg
	cout << endl;
	cout << "Thank You For Using H&S Restaurant System!" << endl;
}
void displayFeedback() 
{
	cout << "Customer Feedback:" << endl;
	for (const Feedback& feedback : feedbackList) {
		cout << "----------------------------------------" << endl;
		cout << "Name: " << feedback.name << endl;
		cout << "Email: " << feedback.email << endl;
		cout << "Comments: " << feedback.comments << endl;
	}
}

int main() {
	displayLogo();
	system("pause");
	system("cls");
	menu();

	// Handle customer orders until 'x' is entered 
	do {
		customerOrder();
	} while (mealtype != 'x' && mealtype != 'X');

	cout << endl;
	char leaveFeedbackChoice;
	cout << "Would you like to leave feedback? (y/n): ";
	cin >> leaveFeedbackChoice;

	if (leaveFeedbackChoice == 'y' || leaveFeedbackChoice == 'Y') {
		system("cls");
		leaveFeedback(); // Call the leaveFeedback() function
		system("cls");
		dailyReport();

		// Display feedback
		displayFeedback();
	}
	else {
		system("cls"); // Clear the screen
		dailyReport();
	}

	return 0;
}
