public class Admin extends User {
    public Admin(String username, String password) {
        super(username, password);  // Call the constructor of the superclass (User) with provided username and password
    }

}
