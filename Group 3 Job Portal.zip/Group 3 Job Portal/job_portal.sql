-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 01, 2024 at 06:06 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `job_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `C_ID` int(11) NOT NULL,
  `C_Name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`C_ID`, `C_Name`) VALUES
(20, 'Administration'),
(16, 'Consulting'),
(11, 'Content Writing'),
(4, 'Customer Service'),
(5, 'Data Analysis'),
(15, 'Education'),
(10, 'Engineering'),
(7, 'Finance'),
(8, 'Graphic Design'),
(13, 'Healthcare'),
(6, 'Human Resources'),
(12, 'IT Support'),
(14, 'Legal'),
(2, 'Marketing'),
(19, 'Operations'),
(18, 'Product Management'),
(9, 'Project Management'),
(17, 'Research'),
(3, 'Sales'),
(1, 'Software Development');

-- --------------------------------------------------------

--
-- Table structure for table `employer`
--

CREATE TABLE `employer` (
  `E_ID` int(11) NOT NULL,
  `E_Name` varchar(100) NOT NULL,
  `E_Email` varchar(256) NOT NULL,
  `E_PhoneNo` varchar(11) NOT NULL,
  `About_Company` text DEFAULT NULL,
  `Location` varchar(256) NOT NULL,
  `E_profile_image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employer`
--

INSERT INTO `employer` (`E_ID`, `E_Name`, `E_Email`, `E_PhoneNo`, `About_Company`, `Location`, `E_profile_image`) VALUES
(2, 'ALICE CHU', 'alice.chu@example.com', '01151539609', 'work', 'kk', 'uploads/profile_images/WhatsApp Image 2021-02-12 at 12.04.57 AM.jpeg'),
(3, 'Tech Innovations Sdn Bhd', 'contact@techinnovations.my', '012-3456789', 'Leading company in technology solutions.', 'Kuala Lumpur', NULL),
(4, 'Green Energy Solutions Sdn Bhd', 'info@greenenergy.my', '013-9876543', 'Experts in renewable energy and sustainability.', 'Selangor', NULL),
(5, 'Creative Minds Agency', 'hello@creativeminds.my', '014-1234567', 'Full-service marketing and advertising agency.', 'Penang', NULL),
(6, 'HealthCare Plus', 'support@healthcareplus.my', '015-2345678', 'Providing top-notch healthcare services.', 'Johor Bahru', NULL),
(7, 'Finance Gurus', 'info@financegurus.my', '016-3456789', 'Your partner in financial growth.', 'Malacca', NULL),
(8, 'Education First Sdn Bhd', 'contact@educationfirst.my', '017-4567890', 'Passionate about quality education.', 'Ipoh', NULL),
(9, 'BuildRight Construction', 'info@buildright.my', '018-5678901', 'Constructing dreams with excellence.', 'Kota Kinabalu', NULL),
(10, 'Travel Adventures Sdn Bhd', 'support@traveladventures.my', '019-6789012', 'Creating unforgettable travel experiences.', 'Kuching', NULL),
(11, 'Culinary Delights', 'hello@culinarydelights.my', '012-7890123', 'Your go-to for gourmet catering services.', 'Shah Alam', NULL),
(12, 'Digital Marketing Agency', 'info@digitalmarketing.my', '013-8901234', 'Specializing in digital marketing strategies.', 'Cyberjaya', NULL),
(13, 'Automotive Solutions', 'contact@automotivesolutions.my', '014-9012345', 'Leading automotive service and repairs.', 'Sibu', NULL),
(14, 'Retail Wonders Sdn Bhd', 'support@retailwonders.my', '015-0123456', 'Innovative retail solutions for businesses.', 'Butterworth', NULL),
(15, 'Fintech Innovations', 'hello@fintechinnovations.my', '016-1234567', 'Transforming the finance sector with technology.', 'Seremban', NULL),
(16, 'Real Estate Experts', 'info@realestateexperts.my', '017-2345678', 'Helping you find your dream home.', 'Kota Bharu', NULL),
(17, 'Logistics and Supply Co.', 'contact@logisticsupply.my', '018-3456789', 'Streamlining your supply chain.', 'Petaling Jaya', NULL),
(19, 'michelle', 'michelle.chin@gmail.com', '0000021345', 'work work work', 'beverly hills phase 3', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `job_application`
--

CREATE TABLE `job_application` (
  `A_ID` int(11) NOT NULL,
  `S_ID` int(11) NOT NULL,
  `L_ID` int(11) NOT NULL,
  `R_ID` int(11) NOT NULL,
  `E_ID` int(11) NOT NULL,
  `Application_Date` date NOT NULL DEFAULT curdate(),
  `Status` enum('accepted','rejected','pending') NOT NULL DEFAULT 'pending',
  `Reviewed_At` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_application`
--

INSERT INTO `job_application` (`A_ID`, `S_ID`, `L_ID`, `R_ID`, `E_ID`, `Application_Date`, `Status`, `Reviewed_At`) VALUES
(1, 1, 1, 1, 2, '2024-09-27', 'rejected', '2024-09-26 16:33:47'),
(5, 3, 1, 2, 2, '2024-09-27', 'accepted', '2024-09-26 16:59:00'),
(6, 3, 1, 2, 2, '2024-09-29', 'accepted', '2024-09-29 05:06:43'),
(7, 3, 2, 2, 2, '2024-09-29', 'accepted', '2024-09-29 05:44:04'),
(8, 3, 1, 2, 2, '2024-09-29', 'accepted', '2024-09-29 07:35:31'),
(9, 3, 2, 2, 2, '2024-09-29', 'accepted', '2024-09-29 14:26:44'),
(10, 3, 1, 2, 2, '2024-09-29', 'accepted', '2024-09-29 14:26:36'),
(11, 3, 2, 2, 2, '2024-09-29', 'accepted', NULL),
(12, 3, 2, 2, 2, '2024-09-29', 'accepted', NULL),
(13, 3, 17, 2, 2, '2024-09-29', 'accepted', '2024-09-29 14:44:09'),
(14, 3, 1, 2, 2, '2024-09-29', 'accepted', NULL),
(15, 3, 1, 2, 2, '2024-09-30', 'accepted', NULL),
(16, 3, 1, 2, 2, '2024-09-30', 'accepted', NULL),
(17, 3, 18, 2, 2, '2024-09-30', 'accepted', '2024-09-30 11:49:54'),
(18, 1, 18, 1, 2, '2024-10-01', 'rejected', '2024-10-01 03:35:27');

-- --------------------------------------------------------

--
-- Table structure for table `job_listing`
--

CREATE TABLE `job_listing` (
  `L_ID` int(11) NOT NULL,
  `E_ID` int(11) NOT NULL,
  `C_ID` int(11) NOT NULL,
  `Job_Name` varchar(100) NOT NULL,
  `Job_Type` text DEFAULT NULL,
  `Salary` text DEFAULT NULL,
  `Job_Responsibilities` text DEFAULT NULL,
  `Requirement` text DEFAULT NULL,
  `Add_On` text DEFAULT NULL,
  `status` enum('available','unavailable') NOT NULL DEFAULT 'available',
  `Created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `view_count` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_listing`
--

INSERT INTO `job_listing` (`L_ID`, `E_ID`, `C_ID`, `Job_Name`, `Job_Type`, `Salary`, `Job_Responsibilities`, `Requirement`, `Add_On`, `status`, `Created_at`, `view_count`) VALUES
(1, 2, 18, 'cust service IT', 'part_time', '1000 - 10000', 'work2', 'work1', 'workworkkkkkkkkkkl', 'available', '2024-09-26 15:33:58', 7),
(2, 2, 20, 'Administrative Assistant', 'Full Time', '3000-3500', 'Handle office tasks, prepare reports.', 'High school diploma or equivalent', 'Experience with office software.', 'available', '2024-09-26 19:49:53', 5),
(3, 3, 16, 'Business Consultant', 'Full Time', '5000-6000', 'Advise companies on business practices.', 'Bachelor\'s in Business Management', 'Experience in consulting preferred.', 'available', '2024-09-26 19:49:53', 0),
(4, 4, 11, 'Content Writer', 'Part Time', '1500-2000', 'Write and edit content for websites.', 'Proven content writing experience.', 'Familiarity with SEO.', 'available', '2024-09-26 19:49:53', 0),
(5, 5, 4, 'Customer Service Representative', 'Full Time', '2500-3000', 'Assist customers with queries and issues.', 'Good communication skills.', 'Experience in customer service is a plus.', 'available', '2024-09-26 19:49:53', 0),
(6, 6, 5, 'Data Analyst', 'Full Time', '4000-4500', 'Analyze datasets to inform business decisions.', 'Degree in Statistics or related field.', 'Proficiency with data analysis tools.', 'available', '2024-09-26 19:49:53', 0),
(7, 7, 15, 'High School Teacher', 'Full Time', '3500-4000', 'Teach students in various subjects.', 'Degree in Education.', 'Classroom teaching experience preferred.', 'available', '2024-09-26 19:49:53', 0),
(8, 8, 10, 'Mechanical Engineer', 'Full Time', '6000-7000', 'Design and develop mechanical systems.', 'Degree in Mechanical Engineering.', 'Experience in mechanical design software.', 'available', '2024-09-26 19:49:53', 0),
(9, 9, 7, 'Financial Analyst', 'Full Time', '5000-6000', 'Provide financial insights for business growth.', 'Degree in Finance.', 'Strong analytical skills.', 'available', '2024-09-26 19:49:53', 0),
(10, 10, 8, 'Graphic Designer', 'Part Time', '2000-2500', 'Design marketing materials and logos.', 'Degree in Graphic Design or related.', 'Proficiency in Adobe Creative Suite.', 'available', '2024-09-26 19:49:53', 0),
(11, 11, 13, 'Nurse', 'Full Time', '4500-5000', 'Provide healthcare services to patients.', 'Degree in Nursing.', 'Registered Nurse license.', 'available', '2024-09-26 19:49:53', 0),
(12, 12, 6, 'HR Manager', 'Full Time', '5000-5500', 'Oversee recruitment and employee relations.', 'Degree in Human Resources.', 'HR management experience.', 'available', '2024-09-26 19:49:53', 0),
(13, 13, 12, 'IT Support Specialist', 'Part Time', '2500-3000', 'Provide technical support to users.', 'Degree in IT or related.', 'Experience in IT support preferred.', 'available', '2024-09-26 19:49:53', 0),
(14, 14, 14, 'Legal Advisor', 'Full Time', '6000-7000', 'Provide legal advice to clients.', 'Degree in Law.', 'Experience in corporate law.', 'available', '2024-09-26 19:49:53', 0),
(15, 15, 2, 'Marketing Executive', 'Full Time', '3500-4000', 'Plan and execute marketing campaigns.', 'Degree in Marketing or related.', 'Experience in digital marketing preferred.', 'available', '2024-09-26 19:49:53', 0),
(16, 16, 3, 'Sales Executive', 'Full Time', '4000-5000', 'Sell products and services to clients.', 'Degree in Sales or related field.', 'Proven sales experience.', 'available', '2024-09-26 19:49:53', 0),
(17, 2, 15, 'Lecturer', 'part_time', '20 - 25/hour', 'workkkkkkk', 'atleast PHD ', 'workkkkkkkk harderrrrrr', 'available', '2024-09-29 14:25:50', 1),
(18, 2, 6, 'HR', 'part_time', '20 - 25/hour', 'workkkkkkkkkkkkkkkkkkkkl', 'atleast spm ', 'workkkkkkkkkkkkkkkkkkkkkkkkkk rajinnnnnnnnnnnnn', 'available', '2024-09-30 11:40:47', 4),
(19, 19, 20, 'Admin Front Desk', 'full_time', '1000 - 1500', 'work as admin', 'work as admin', 'work as admin', 'unavailable', '2024-10-01 03:18:55', 0),
(20, 19, 20, 'Admin Front Desk', 'full_time', '1000 - 1500', 'work as admin', 'work as admin', 'work as admin', 'available', '2024-10-01 03:20:18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `job_seeker`
--

CREATE TABLE `job_seeker` (
  `S_ID` int(11) NOT NULL,
  `S_Name` varchar(100) NOT NULL,
  `Gender` char(1) DEFAULT NULL CHECK (`Gender` in ('M','F')),
  `Age` int(11) NOT NULL,
  `S_PhoneNo` varchar(11) NOT NULL,
  `S_Email` varchar(256) NOT NULL,
  `Address` varchar(256) NOT NULL,
  `AboutMe` text DEFAULT NULL,
  `S_profile_image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_seeker`
--

INSERT INTO `job_seeker` (`S_ID`, `S_Name`, `Gender`, `Age`, `S_PhoneNo`, `S_Email`, `Address`, `AboutMe`, `S_profile_image`) VALUES
(1, 'vincent chu', 'M', 20, '01151539608', 'vincent.chu@example.com', 'beverly hills phase 2 block J3-3', 'i am hardworking', 'WhatsApp Image 2021-02-12 at 12.04.57 AM.jpeg'),
(3, 'John Doe', 'M', 28, '1234567890', 'john.doe@example.com', 'beverly hills phase 2 block J3-3', 'i work very slow', 'works.jpg'),
(4, 'natalie koa', 'F', 123, '0123456789', 'natalie@example.com', 'sabah', 'workkkkkkkkkkkl', 'chagee.png'),
(18, 'alex chu', 'M', 20, '0909091111', 'alex.chu@email.com', 'beverly hills phase 2 block J3-3 penampang', 'hard working individual', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `resume`
--

CREATE TABLE `resume` (
  `R_ID` int(11) NOT NULL,
  `S_ID` int(11) NOT NULL,
  `Detail` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `resume`
--

INSERT INTO `resume` (`R_ID`, `S_ID`, `Detail`) VALUES
(1, 1, 'uploads/fileUpload/Your paragraph text.pdf'),
(2, 3, 'uploads/fileUpload/Your paragraph text.pdf'),
(3, 4, 'uploads/fileUpload/DSF_Michelle Chin Koh Ying_23SMD05432_Resume (1).pdf'),
(4, 18, 'very hard working individual');

-- --------------------------------------------------------

--
-- Table structure for table `saved_jobs`
--

CREATE TABLE `saved_jobs` (
  `S_ID` int(11) NOT NULL,
  `L_ID` int(11) NOT NULL,
  `Saved_At` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `saved_jobs`
--

INSERT INTO `saved_jobs` (`S_ID`, `L_ID`, `Saved_At`) VALUES
(3, 1, '2024-09-29 05:42:09'),
(3, 2, '2024-09-29 05:44:29'),
(3, 17, '2024-09-29 14:42:08'),
(3, 18, '2024-09-30 11:49:22');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `U_ID` int(11) NOT NULL,
  `U_name` varchar(100) NOT NULL,
  `U_Email` varchar(100) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `U_profile_image` varchar(255) DEFAULT NULL,
  `Role` enum('job_seeker','employer') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`U_ID`, `U_name`, `U_Email`, `Password`, `U_profile_image`, `Role`) VALUES
(1, 'vincent chu', 'vincent.chu@example.com', '$2y$10$ui.pIo8Tdq6a9dWWqkc8M.HOYUBsX9zOzmE66nkTLjluPwFgLE/MG', NULL, 'job_seeker'),
(2, 'alice chu', 'alice.chu@example.com', '$2y$10$fBEGPu7RlTIX.v6t7UvmLuXKp85MymIboCBM5QY2asUtHDipZiV5q', NULL, 'employer'),
(3, 'John Doe', 'john.doe@example.com', '$2y$10$C78fc0xhYTV.7B7lBjCZteMNJ/lYZHVzhsGGcnGdm7idcKKP7AD2G', NULL, 'job_seeker'),
(4, 'natalie koa', 'natalie@example.com', '$2y$10$u8Aun1ObIITFdnf9zUF7S.k/AuGHQ/9fSO311SePo2lRpB8M8olV6', NULL, 'job_seeker'),
(6, 'abc ', 'abc@example.com', '$2y$10$zZe03G3.kX2567L6UnLFQeCgSCwcCl4hBHrSSQy9/Bo9FrjRf.NB6', NULL, 'job_seeker'),
(7, '123', '123@example.com', '$2y$10$ATI.zGhqnc2C7gx2dRG4H.pjZ3.HEeCL39z.XOCTY./aGWDaRvplm', NULL, 'job_seeker'),
(8, 'elisha', 'elisha@example.com', '$2y$10$Ec.mS5Ql9z9zKlJMyXFSdet6GD.SIF12cmCIZJCjDdmKRTkmjhBti', NULL, 'job_seeker'),
(9, 'niao ', 'niao@example.com', '$2y$10$CE6pXSsXmjPKlJMb43GhPe5pNixBLimkMIDmkI6ZxDL359.Kr115C', NULL, 'job_seeker'),
(18, 'alex chu', 'alex.chu@email.com', '$2y$10$cotd7BYyVPdFQ3aD8kR7jukx.MGaMKeErNrqRa05xqeJGP3z8eddS', NULL, 'job_seeker'),
(19, 'michelle', 'michelle.chin@gmail.com', '$2y$10$/MipMx9GDKM09qNT82YIjeJynQoBKwU5b0FqnXzq9sjiIyzVT8xGe', NULL, 'employer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`C_ID`),
  ADD UNIQUE KEY `C_Name` (`C_Name`);

--
-- Indexes for table `employer`
--
ALTER TABLE `employer`
  ADD PRIMARY KEY (`E_ID`),
  ADD UNIQUE KEY `E_Email` (`E_Email`),
  ADD UNIQUE KEY `E_PhoneNo` (`E_PhoneNo`);

--
-- Indexes for table `job_application`
--
ALTER TABLE `job_application`
  ADD PRIMARY KEY (`A_ID`),
  ADD KEY `S_ID` (`S_ID`),
  ADD KEY `L_ID` (`L_ID`),
  ADD KEY `R_ID` (`R_ID`),
  ADD KEY `E_ID` (`E_ID`);

--
-- Indexes for table `job_listing`
--
ALTER TABLE `job_listing`
  ADD PRIMARY KEY (`L_ID`),
  ADD KEY `E_ID` (`E_ID`),
  ADD KEY `C_ID` (`C_ID`);

--
-- Indexes for table `job_seeker`
--
ALTER TABLE `job_seeker`
  ADD PRIMARY KEY (`S_ID`),
  ADD UNIQUE KEY `S_PhoneNo` (`S_PhoneNo`),
  ADD UNIQUE KEY `S_Email` (`S_Email`);

--
-- Indexes for table `resume`
--
ALTER TABLE `resume`
  ADD PRIMARY KEY (`R_ID`),
  ADD KEY `S_ID` (`S_ID`);

--
-- Indexes for table `saved_jobs`
--
ALTER TABLE `saved_jobs`
  ADD PRIMARY KEY (`S_ID`,`L_ID`),
  ADD KEY `L_ID` (`L_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`U_ID`),
  ADD UNIQUE KEY `U_Email` (`U_Email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `C_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `employer`
--
ALTER TABLE `employer`
  MODIFY `E_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `job_application`
--
ALTER TABLE `job_application`
  MODIFY `A_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `job_listing`
--
ALTER TABLE `job_listing`
  MODIFY `L_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `job_seeker`
--
ALTER TABLE `job_seeker`
  MODIFY `S_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `resume`
--
ALTER TABLE `resume`
  MODIFY `R_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `U_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `job_application`
--
ALTER TABLE `job_application`
  ADD CONSTRAINT `job_application_ibfk_1` FOREIGN KEY (`S_ID`) REFERENCES `job_seeker` (`S_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `job_application_ibfk_2` FOREIGN KEY (`L_ID`) REFERENCES `job_listing` (`L_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `job_application_ibfk_3` FOREIGN KEY (`R_ID`) REFERENCES `resume` (`R_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `job_application_ibfk_4` FOREIGN KEY (`E_ID`) REFERENCES `employer` (`E_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `job_listing`
--
ALTER TABLE `job_listing`
  ADD CONSTRAINT `job_listing_ibfk_1` FOREIGN KEY (`E_ID`) REFERENCES `employer` (`E_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `job_listing_ibfk_2` FOREIGN KEY (`C_ID`) REFERENCES `category` (`C_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `resume`
--
ALTER TABLE `resume`
  ADD CONSTRAINT `resume_ibfk_1` FOREIGN KEY (`S_ID`) REFERENCES `job_seeker` (`S_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `saved_jobs`
--
ALTER TABLE `saved_jobs`
  ADD CONSTRAINT `saved_jobs_ibfk_1` FOREIGN KEY (`S_ID`) REFERENCES `job_seeker` (`S_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `saved_jobs_ibfk_2` FOREIGN KEY (`L_ID`) REFERENCES `job_listing` (`L_ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
